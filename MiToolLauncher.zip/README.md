# MiTool Launcher (unofficial)

A small Android app with buttons that run [MiTool](https://github.com/MiForge/MiTool)
inside Termux. It is **not** affiliated with MiForge or Xiaomi, and it does not contain MiTool.

## Why a launcher and not a "real" APK?

MiTool talks to a phone over USB using Termux:API (`termux-usb`) and libusb.
A normal APK cannot do this the same way, so this app only sends commands to Termux,
and Termux does the USB work.

## Get the APK from GitHub (no PC needed)

1. Create a new GitHub repository and upload everything from this folder
   (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow**.
3. When it finishes (about 3-5 minutes), open the run and download the
   **MiTool-Launcher-apk** artifact. Unzip it and install `app-debug.apk`.

## Use

1. Open this app. In Step 1 tap **Download & install Termux**, then **Download & install Termux:API**.
   They are downloaded from the official GitHub releases. Both must come from the same source,
   so do not mix them with F-Droid or Play Store versions. Open Termux once and let its first-time
   setup finish.
2. Step 2: copy the command, paste it in Termux, press Enter, then fully close and reopen Termux.
   (Android does not let an app do this for you.)
3. Tap **Install / update MiTool** once.
4. Connect the other Xiaomi phone with a USB OTG cable and tap a tool button.
   Allow the USB popup from Termux:API when it appears.

Unlocking the bootloader erases all data on the phone being unlocked.

## Files

- `app/src/main/java/com/mitool/launcher/MainActivity.java` - the whole app
- `app/src/main/AndroidManifest.xml` - needs the `com.termux.permission.RUN_COMMAND` permission
- `.github/workflows/build-apk.yml` - builds the debug APK on GitHub

MiTool itself is Apache-2.0 licensed by its authors.
