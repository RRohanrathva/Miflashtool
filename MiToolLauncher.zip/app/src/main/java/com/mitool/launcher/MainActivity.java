package com.mitool.launcher;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Unofficial launcher for MiTool (https://github.com/MiForge/MiTool).
 * It does not contain MiTool. It installs Termux + Termux:API from GitHub and asks
 * Termux to run the commands, because MiTool needs Termux + Termux:API to talk to a
 * phone over USB OTG.
 */
public class MainActivity extends Activity {

    private static final String TERMUX_PKG = "com.termux";
    private static final String TERMUX_API_PKG = "com.termux.api";
    private static final String RUN_PERMISSION = "com.termux.permission.RUN_COMMAND";
    private static final String TERMUX_HOME = "/data/data/com.termux/files/home";
    private static final String TERMUX_BIN = "/data/data/com.termux/files/usr/bin";

    // Both apps must come from the same source (same signing key), so both come from GitHub.
    private static final String API_TERMUX =
            "https://api.github.com/repos/termux/termux-app/releases/latest";
    private static final String API_TERMUX_API =
            "https://api.github.com/repos/termux/termux-api/releases/latest";

    private static final String INSTALL_CMD =
            "curl -sS https://raw.githubusercontent.com/MiForge/MiTool/main/install.sh | bash";
    private static final String ALLOW_CMD =
            "mkdir -p ~/.termux && echo 'allow-external-apps=true' >> ~/.termux/termux.properties";

    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("MiTool Launcher");
        title.setTextSize(24f);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Unofficial helper for MiTool. It runs MiTool inside Termux.");
        sub.setPadding(0, dp(4), 0, dp(12));
        root.addView(sub);

        statusView = new TextView(this);
        statusView.setPadding(0, 0, 0, dp(8));
        root.addView(statusView);

        addHeader(root, "Step 1 - Install Termux and Termux:API");
        addNote(root, "Downloads the latest versions from GitHub. Install Termux first, then Termux:API. "
                + "Android will ask you to allow installs from this app and to confirm each install. "
                + "After installing, open Termux once and wait until its first-time setup finishes.");
        addButton(root, "Download & install Termux", new View.OnClickListener() {
            @Override public void onClick(View v) {
                downloadAndInstall(API_TERMUX, "Termux");
            }
        });
        addButton(root, "Download & install Termux:API", new View.OnClickListener() {
            @Override public void onClick(View v) {
                downloadAndInstall(API_TERMUX_API, "Termux:API");
            }
        });

        addHeader(root, "Step 2 - Allow this app to control Termux");
        addNote(root, "Open Termux, paste the copied command, press Enter, then fully close and reopen Termux. "
                + "Android does not let any app do this step for you.");
        addButton(root, "Copy 'allow external apps' command", new View.OnClickListener() {
            @Override public void onClick(View v) { copyAllowCommand(); }
        });
        addButton(root, "Open Termux", new View.OnClickListener() {
            @Override public void onClick(View v) { openTermux(); }
        });

        addHeader(root, "Step 3 - Install MiTool");
        addNote(root, "Run once. Also use it to update. Needs internet.");
        addButton(root, "Install / update MiTool", new View.OnClickListener() {
            @Override public void onClick(View v) { runInTermux(INSTALL_CMD); }
        });

        addHeader(root, "Step 4 - Use MiTool");
        addNote(root, "Connect the other Xiaomi phone with a USB OTG cable. Unlocking the bootloader erases all data on that phone.");
        addButton(root, "MiTool menu", new View.OnClickListener() {
            @Override public void onClick(View v) { runInTermux("mitool"); }
        });
        addTool(root, "Unlock Bootloader", "1");
        addTool(root, "Flash Fastboot ROM (.tgz)", "2");
        addTool(root, "Mi Assistant", "3");
        addTool(root, "Firmware Content Extractor", "4");
        addTool(root, "Apply Unlock Permission", "5");

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        statusView.setText(
                "Termux: " + (isInstalled(TERMUX_PKG) ? "installed" : "NOT installed") + "\n"
                        + "Termux:API: " + (isInstalled(TERMUX_API_PKG) ? "installed" : "NOT installed"));
    }

    // ---- install Termux / Termux:API from GitHub -----------------------

    private void downloadAndInstall(final String apiUrl, final String label) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            toast("Allow 'Install unknown apps' for MiTool Launcher, then press back and tap the button again.");
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }

        toast("Finding latest " + label + "...");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String json = httpGet(apiUrl);
                    JSONArray assets = new JSONObject(json).getJSONArray("assets");

                    String bestUrl = null;
                    String bestName = null;
                    int bestScore = -1;
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject a = assets.getJSONObject(i);
                        String name = a.getString("name");
                        if (!name.endsWith(".apk")) continue;
                        // Prefer the GitHub build, the universal build, and the Android 7+ build.
                        int score = (name.contains("github") ? 4 : 0)
                                + (name.contains("universal") ? 2 : 0)
                                + (name.contains("android-7") ? 1 : 0);
                        if (score > bestScore) {
                            bestScore = score;
                            bestName = name;
                            bestUrl = a.getString("browser_download_url");
                        }
                    }
                    if (bestUrl == null) throw new Exception("No APK found in the latest release");

                    downloadThenInstall(bestUrl, bestName, label);
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            toast("Failed: " + e.getMessage());
                        }
                    });
                }
            }
        }).start();
    }

    private void downloadThenInstall(String url, String fileName, final String label) throws Exception {
        final DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
        req.setTitle(label);
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        req.setDestinationInExternalFilesDir(this, null, fileName);
        final long id = dm.enqueue(req);

        runOnUiThread(new Runnable() {
            @Override public void run() {
                toast("Downloading " + label + "... Install screen opens when it is done.");
            }
        });

        boolean done = false;
        for (int i = 0; i < 600 && !done; i++) {          // wait up to ~10 minutes
            Thread.sleep(1000);
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(id));
            if (c == null) throw new Exception("Download was cancelled");
            try {
                if (!c.moveToFirst()) throw new Exception("Download was cancelled");
                int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    done = true;
                } else if (status == DownloadManager.STATUS_FAILED) {
                    throw new Exception("Download failed. Check internet and try again.");
                }
            } finally {
                c.close();
            }
        }
        if (!done) throw new Exception("Download is taking too long");

        final Uri apk = dm.getUriForDownloadedFile(id);
        runOnUiThread(new Runnable() {
            @Override public void run() {
                installApk(apk);
            }
        });
    }

    private void installApk(Uri apk) {
        if (apk == null) {
            toast("Downloaded file not found. Open the Downloads notification and tap the APK.");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(apk, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Could not open the installer. Open the Downloads notification and tap the APK.");
        }
    }

    private String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setRequestProperty("User-Agent", "MiToolLauncher");
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        try {
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            in.close();
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    // ---- run commands in Termux ----------------------------------------

    private void runInTermux(String command) {
        if (!isInstalled(TERMUX_PKG)) {
            toast("Termux is not installed. Do Step 1 first.");
            return;
        }

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{RUN_PERMISSION}, 1);
            toast("Allow the permission, then tap the button again.");
            return;
        }

        String full = "export PATH=" + TERMUX_BIN + ":$PATH; " + command
                + "; echo; echo '--- Done. Press Enter to close ---'; read _";

        Intent intent = new Intent("com.termux.RUN_COMMAND");
        intent.setClassName(TERMUX_PKG, "com.termux.app.RunCommandService");
        intent.putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BIN + "/bash");
        intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-c", full});
        intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME);
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
        intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0");

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            toast("Could not talk to Termux. Do Step 2 (allow external apps), then retry.");
        }
    }

    private void addTool(LinearLayout root, String label, final String choice) {
        addButton(root, label, new View.OnClickListener() {
            @Override public void onClick(View v) { runInTermux("mitool " + choice); }
        });
    }

    private void copyAllowCommand() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("termux-allow-external-apps", ALLOW_CMD));
            toast("Command copied. Paste it in Termux.");
        }
    }

    private void openTermux() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(TERMUX_PKG);
        if (launch == null) {
            toast("Termux is not installed. Do Step 1 first.");
            return;
        }
        startActivity(launch);
    }

    // ---- helpers -------------------------------------------------------

    private boolean isInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void addHeader(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(18f);
        t.setPadding(0, dp(16), 0, dp(4));
        root.addView(t);
    }

    private void addNote(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setPadding(0, 0, 0, dp(4));
        root.addView(t);
    }

    private void addButton(LinearLayout root, String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        root.addView(b, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
